/**
 * This is a text based RPG for kids from ages 6-12. It involves solving problems, facing challenges and overcoming obstacles. The user will have to help Moana
 * restore the heart of Te Fiti by using their Math and Reading skills. They will also require the ability to win mini games such as Snakes and Ladders and Rock, 
 * Paper, Scissors. It's an amazing game filled with great learning opportunities and fun!
 */
//Vidhi Pandya
//October 30th 2018
//Moana Themed RPG Game
public class RPG
{
    public static void main (String Args [])
    {
        new RPG ();
    }

    public RPG ()
    {
        password1 ();
    }

    public void password1 () 
    {
        //use ascii art to greet player
        System.out.println ("##      ## ######## ##        ######   #######  ##     ## ######## ");
        System.out.println ("##  ##  ## ##       ##       ##    ## ##     ## ###   ### ##       ");
        System.out.println ("##  ##  ## ##       ##       ##       ##     ## #### #### ##       ");
        System.out.println ("##  ##  ## ######   ##       ##       ##     ## ## ### ## ######   ");
        System.out.println ("##  ##  ## ##       ##       ##       ##     ## ##     ## ##       ");
        System.out.println ("##  ##  ## ##       ##       ##    ## ##     ## ##     ## ##       ");
        System.out.println (" ###  ###  ######## ########  ######   #######  ##     ## ######## ");

        //Welcome the user and explain how they will have to figure out the password before entering the game
        System.out.println ("\nBefore you enter the amazing, fun and adventurous game of Moana and Te Fiti's Heart, you will have to figure out the secret"); 
        System.out.println ("password");

        //Introduce how the user has to figure out the password, they need to unscramble four words and solve a riddle
        System.out.println ("\nYour password has a length of four words. You will have to unscramble all four to begin your game."); 
        System.out.println ( "You will also have a quick riddle to solve!");

        //First, the user has to unscramble four words
        System.out.println ("\nFirst, you will have to unscramble four words and put them together to reveal your final answer!");

        //The first word to unscramble is "long"
        System.out.println ("\nYour first word to unscramble is: gnlo");
        String unscramble1 = IBIO.inputString ("What is the unscrambled word?: ");

        //if the answer is correct continue, if not, call Quit method to leave the game
        //make the answer into all lowercases so the program can read the input without difficulties
        if (unscramble1.toLowerCase().equals ("long"))
        {
            System.out.println ("\nYou are correct!");
            password2 ();
        }
        else 
        {
            quit ();
        }
    }

    public void password2 ()
    {
        //The second word to unscramble is "time"
        System.out.println ("\nYour second word to unscramble is: imte");
        String unscramble2 = IBIO.inputString ("What is the unscrambled word?: ");

        //if the answer is correct continue, if not, call Quit method to leave the game
        //make the answer into all lowercases so the program can read the input without difficulties
        if (unscramble2.toLowerCase().equals ("time"))
        {
            System.out.println ("\nYou are correct!");
            password3 ();
        }
        else 
        {
            quit ();
        }
    }

    public void password3 ()
    {
        //The third word to unscramble is "no"
        System.out.println ("\nYour third word to unscramble is: on");
        String unscramble3 = IBIO.inputString ("What is the unscrambled word?: ");

        //if the answer is correct continue, if not, call Quit method to leave the game
        //make the answer into all lowercases so the program can read the input without difficulties
        if (unscramble3.toLowerCase().equals ("no"))
        {
            System.out.println ("\nYou are correct!");
            password4 ();
        }
        else 
        {
            quit ();
        }
    }

    public void password4 ()
    {
        //The fourth word to unscramble is "sea"
        System.out.println ("\nYour fourth word to unscramble is: esa");
        String unscramble4 = IBIO.inputString ("What is the unscrambled word?: ");

        //if the answer is correct continue, if not, call Quit method to leave the game
        //make the answer into all lowercases so the program can read the input without difficulties
        if (unscramble4.toLowerCase().equals ("sea"))
        {
            System.out.println ("\nYou are correct!");
            finalpasswordunscramble ();
        }
        else 
        {
            quit ();
        }
    }

    public void finalpasswordunscramble ()
    {
        //ask user to enter the final correct answer
        String finalanswer = IBIO.inputString ("\nWhat is the final answer? - ");

        //if the final answer is correct, let the user user continue, if not, call Quit Method to leave the game
        //make the answer into all lowercases so the program can read the input without difficulties
        if (finalanswer.toLowerCase().equals ("long time no sea"))
        {
            System.out.println ("\nYou are correct!");
            riddlepassword ();
        }
        else 
        {
            quit ();
        }
    }

    public void riddlepassword ()
    {
        //introduce the riddle to the user
        System.out.println ("\nNow, you have to solve this riddle!!");
        System.out.println ("Riddle: What did the ocean say to the sand?");

        //give them a multiple choices for the riddle as it may be difficult for the user to figure out the answer
        System.out.println ("\nYou have four options to select from.");
        System.out.println ("a) HIII");
        System.out.println ("b) nothing");
        System.out.println ("c) it waved");
        System.out.println ("d) nothing. it waved.");

        //ask the user to select an answer and print the letter
        char riddle = IBIO.inputChar ("\nEnter a letter for the answer of the riddle: ");

        //if the selection is correct, congratulate the user and call the next method to proceed to the next stage, if not, call Quit method
        //make the answer into all lowercases so the program can read the input without difficulties
        if (Character.toLowerCase(riddle) == 'd')
        {
            System.out.println ("\nYou are correct!");
            intro ();
        }
        else 
        {
            quit ();
        }
    }

    public void intro () 
    {
        //greet the player and introduce them to the World of Motunui and Moana
        System.out.println ("\nWelcome to Motunui! Today, you will help Moana restore the heart from Maui and stop the island from destruction!"); 

        //introduce the back story of the adventures the user will face
        System.out.println ("Wait… you don’t know what I’m talking about, do you? Well…, let’s take a walk back into the past.");

        //Use a wave ASCII as the theme of the game is water, islands and tropical environments
        System.out.println("\n``````````````````````````````````````````````````");
        System.out.println("``````````...-:--..```````````````````````````````");
        System.out.println("````````-+o++oooo+/-.`````````````````````````````");
        System.out.println("`````./sysoooooo++:-:-````````````````````````````");
        System.out.println("```-+osss+oooo+-..-:::````````````````````````````");
        System.out.println("` :osoooo++oooo.````..`````````````````````````````");
        System.out.println("`/sss++o+oo+oo.`````````````..--.`````````````````");
        System.out.println("`:yso++o++o+oo+oooooooooooosss/::::::.......``````");
        System.out.println("`:so+++o+++oooooossssyyyyyyyyyyyyyyyyssssssso++-``");
        System.out.println("`:soo+++o++++oo+++oooossssssyyyyyyyyyysyyyyyysys:`");
        System.out.println("`:sssso++o++++++++oo++++ooooooooooooooooooosssss:`");
        System.out.println("`:ooooooooo++++++++++o+++++++ooooooooooosssooooo-`");
        System.out.println("``````````````````````````````````````````````````");
        System.out.println("``````````...-:--..```````````````````````````````");

        //Begin the story and introduce the characters
        System.out.println ("\nThere is a mother island, Te Fiti. With her heart, Te Fiti possessed the power to create life and bring other islands to existence.");
        System.out.println ("However, many desired to have the power of her heart. Yet, only one had the courage to do it.");
        System.out.println ("The demigod, Maui used his special magic hook to shape shift into various creatures. ");

        //Include an ASCII art of the hook to show a visual to the user
        System.out.println ("\n          -:.-://::-.            ");         
        System.out.println ("         -+o+++s+++/+:.          ");          
        System.out.println ("        `++/++/+++/++o+.         ");          
        System.out.println ("       `://-.```.-:++++/         ");         
        System.out.println ("       `/:.       `-++/:`        ");          
        System.out.println ("       -//`        `:///`        ");          
        System.out.println ("       ./:-.-`      -+/:         ");          
        System.out.println ("       `-/+:-      `-:/-         ");          
        System.out.println ("        `.---.     `//-`         ");          
        System.out.println ("         `...`    -:/.           ");         
        System.out.println ("                  `:--`          ");          
        System.out.println ("                  .:-`           ");          
        System.out.println ("                 `---            ");          
        System.out.println ("                 -++/`           ");          
        System.out.println ("                `ohhy`           ");          
        System.out.println ("                `ohhy-           ");          
        System.out.println ("                `ohhys-          ");          
        System.out.println ("               `:hhhhs`          ");         
        System.out.println ("                .dhyy.           ");         
        System.out.println ("                 `+yhs           ");         
        System.out.println ("                  .o+`           ");          
        System.out.println ("                  ``             ");  

        //tell the user why the hook was used
        System.out.println ("\nHe used this hook to travel to Te Fiti and steal the heart. The heart is a small green gemstone engraved with a spiral.");

        //show the user a visual of Te Fiti's heart
        System.out.println ("\nMMMMMMNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNMMMMMM");
        System.out.println ("MMMMNNNNNNNNNNNNNNNNdhso++osydNNNNNNNNNNNNNNNNMMMM");
        System.out.println ("MMNNNNNNNNNNNNNNNdo:-...://:--:odNNNNNNNNNNNNNNNMM");
        System.out.println ("MNNNNNNNNNNNNNNd+-...-/syyyyys+:-/dNNNNNNNNNNNNNNM");
        System.out.println ("NNNNNNNNNNNNNNs-..../soooosyy+//-..oNNNNNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNNNm+...`.os/osss:+/-ss///./mNNNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNNN+..:..oys:o+/::+s//+oss/.+NNNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNNy.`/-`/s++sooossyyyso+//+:.sNNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNN-`-o.`o/+/syo/-..--/osyy++.-mNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNh``/s``ooooo-`-:+++/-.-os-+:`yNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNo``:+.`+yoo:`/o//oyhy+`.ooo+`+NNNNNNNNNN");
        System.out.println ("NNNNNNNNNN+``./:`-o::o-:+//syyhy:`/soo`/NNNNNNNNNN");
        System.out.println ("NNNNNNNNNNo``oss.`ossyo++--oo:+y+`-s/:`+NNNNNNNNNN");
        System.out.println ("NNNNNNNNNNy``+yy+`.oyy/+s/`:s+:y/`:s--`sNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNm.`-+o+o-.:osso-`:yhhy-`oys-.dNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNNo..s+ohyo:..-.-/o+oy/`:hd+.+NNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNNm:.-/shhho/osyho//o/`-y+o.-mNNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNNNd-.-shs//o++ydsso:`:yho.-dNNNNNNNNNNNN");
        System.out.println ("NNNNNNNNNNNNNd/.-shhy+ydddho-.+hho.:dNNNNNNNNNNNNN");
        System.out.println ("MNNNNNNNNNNNNNNs-.:shhhyo/--/yho:-ommNNNNNNNNNNNNM");
        System.out.println ("MMNNNNNNNNNNNNNNms:......-/++:-:odNdsmNNNNNNNNNNMM");
        System.out.println ("MMMMNNNNNNNNNNNNNNNhs+:----:+shNNNNmNNNNNNNNNNMMMM");
        System.out.println ("MMMMMMNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNMMMMMM");

        //Finish the story and tell the user what they need to do to accomplish all objectives and goals of the game
        System.out.println ("\nWithout the heart, the island starts to worsen and sends forth a horrible darkness."); 
        System.out.println ("Maui escaped with the heart, however, he was confronted by Te Ka, a demon of lava and fire.");
        System.out.println ("Maui and Te Ka engaged in a battle but Maui was struck from the sky. He lost his hook and Te Fiti’s heart to the sea. ");
        System.out.println ("Thousands of years later, Te Ka (the volcano) and other creatures continue to hunt for the");  
        System.out.println ("heart as darkness continues to take over our islands. You have to help Moana find the heart!! Today, you will face various ");
        System.out.println ("challenges to find the heart and restore it to save your island and many other islands from destruction. You will help ");
        System.out.println ("Moana face three main challenges in order to restore the heart and save Moana’s island from destruction! ");

        //ask the user if they're ready to begin their adventures to make the game engaging
        char engage = IBIO.inputChar ("\nARE YOU READY? y/n ");
        //make the answer into all lowercases so the program can read the input without difficulties
        //if the user says yes, they continue, if not, they do not
        if (Character.toLowerCase(engage) == 'y')
        {
            stage1 ();
        }
        else 
        {
            quit ();
        }
    }

    public void stage1 ()
    {
        //use ascii art to introduce the first stage
        System.out.println ("\n ######  ########    ###     ######   ########       ##   ");
        System.out.println ("##    ##    ##      ## ##   ##    ##  ##           ####   ");
        System.out.println ("##          ##     ##   ##  ##        ##             ##   ");
        System.out.println (" ######     ##    ##     ## ##   #### ######         ##   ");
        System.out.println ("      ##    ##    ######### ##    ##  ##             ##   ");
        System.out.println ("##    ##    ##    ##     ## ##    ##  ##             ##   ");   
        System.out.println (" ######     ##    ##     ##  ######   ########     ###### ");

        //introduce the story of Moana
        System.out.println ("\nMoana’s father, Chief Tui does not let Moana go near the ocean. He believes that it is dangerous and that they are safe on their ");
        System.out.println ("island! However, Moana continues to come back to the sea as it intrigues her and she wants to discover and learn more about the");  
        System.out.println ("ocean. Moana’s grandmother continues to encourage her to follow her heart and listen to the voice inside her head that tells");  
        System.out.println ("her to go back. Moana finally decides to take a canoe and see if she can find any fish beyond the reef as the ones near her");  
        System.out.println ("island are damaged due to the continuous destruction of her island. Now it’s your turn to help Moana learn how to ride  ");
        System.out.println ("her canoe safely in the ocean! You have to correctly answer the following questions in order to help her learn!! ");

        //make a variable to count points
        int c = 0;

        //ask the question
        System.out.println ("\nMultiple Choice 1: ");
        System.out.println ("What is the pronoun in this sentence? - The girl was very angry. She had a horrible day.");
        System.out.println ("   a) She");
        System.out.println ("   b) Girl");
        System.out.println ("   c) Had ");
        System.out.println ("   d) Him");

        //ask the user for the answer
        char mc1 = IBIO.inputChar ("\nEnter a letter for the correct answer: ");
        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        if (Character.toLowerCase(mc1) == 'a')
        {
            //if the user is correct, congratulate them and add 1 to the total score
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //ask the question
        System.out.println ("\nMultiple Choice 2: ");
        System.out.println ("What is the pronoun in this sentence? - He was a very smart boy.");
        System.out.println ("   a) Very");
        System.out.println ("   b) Boy");
        System.out.println ("   c) He ");
        System.out.println ("   d) Smart");

        //ask the user for the answer
        char mc2 = IBIO.inputChar ("\nEnter a letter for the correct answer: ");
        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        if (Character.toLowerCase(mc2) == 'c')
        {
            //if the user is correct, congratulate them and add 1 to the total score
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //ask the question
        System.out.println ("\nMultiple Choice 3: ");
        System.out.println ("What is the verb in this sentence? - Tommy was running very fast.");
        System.out.println ("   a) Fast");
        System.out.println ("   b) Running");
        System.out.println ("   c) Tommy ");
        System.out.println ("   d) Walking");

        //ask the user for the answer
        char mc3 = IBIO.inputChar ("\nEnter a letter for the correct answer: ");
        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        if (Character.toLowerCase(mc3) == 'b')
        {
            //if the user is correct, congratulate them and add 1 to the total score
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //ask the question
        System.out.println ("\nMultiple Choice 4: ");
        System.out.println ("What is the adjective in this sentence? - The chair was very ugly."); 
        System.out.println ("   a) Chair");
        System.out.println ("   b) Ugly");
        System.out.println ("   c) Was ");
        System.out.println ("   d) Very");

        //ask the user for the answer
        char mc4 = IBIO.inputChar ("\nEnter a letter for the correct answer: ");
        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        if (Character.toLowerCase(mc4) == 'b')
        {
            //if the user is correct, congratulate them and add 1 to the total score
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //ask the question
        System.out.println ("\nMultiple Choice 5: ");
        System.out.println ("What is the noun in this sentence? - The bird was flying very slowly."); 
        System.out.println ("   a) Flying");
        System.out.println ("   b) Slowly");
        System.out.println ("   c) Plane ");
        System.out.println ("   d) Bird");

        //ask the user for the answer
        char mc5 = IBIO.inputChar ("\nEnter a letter for the correct answer: ");
        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        if (Character.toLowerCase(mc5) == 'd')
        {
            //if the user is correct, congratulate them and add 1 to the total score 
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //ask the question
        System.out.println ("\nTrue or False 1:");
        System.out.println ("A noun is a person place or thing");
        System.out.println ("Is the statement above true or false?");

        //ask the user for the answer
        char tf1 = IBIO.inputChar ("\nEnter a letter for the correct answer t/f: ");
        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        if (Character.toLowerCase (tf1) == 't')
        {
            //if the user is correct, congratulate them and add 1 to the total score 
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //ask the question
        System.out.println ("\nTrue or False 2:");
        System.out.println ("An adjective is an action word");
        System.out.println ("Is the statement above true or false?");

        //ask the user for the answer
        char tf2 = IBIO.inputChar ("\nEnter a letter for the correct answer t/f: ");
        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        if (Character.toLowerCase (tf2) == 'f')
        {
            //if the user is correct, congratulate them and add 1 to the total score 
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //ask the question
        System.out.println ("\nTrue or False 3:");
        System.out.println ("A verb is a descriptive word");
        System.out.println ("Is the statement above true or false?");

        //ask the user for the answer
        char tf3 = IBIO.inputChar ("\nEnter a letter for the correct answer t/f: ");
        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        if (Character.toLowerCase (tf3) == 'f')
        {
            //if the user is correct, congratulate them and add 1 to the total score
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //ask the question
        System.out.println ("\nTrue or False 4:");
        System.out.println ("An example of a pronoun is SHE");
        System.out.println ("Is the statement above true or false");

        //ask the user for the answer
        char tf4 = IBIO.inputChar ("\nEnter a letter for the correct answer t/f: ");
        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        if (Character.toLowerCase (tf4) == 't')
        {
            //if the user is correct, congratulate them and add 1 to the total score
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //ask the question
        System.out.println ("\nTrue or False 5:");
        System.out.println ("The following sentence is written in Past Tense - Tommy had an amazing Birthday Party!");
        System.out.println ("Is the statement above true or false");

        //if the answer is put to all lowercases, it makes it easier for the code to read if the user is correct
        char tf5 = IBIO.inputChar ("\nEnter a letter for the correct answer t/f: ");
        if (Character.toLowerCase (tf5) == 't')
        {
            //if the user is correct, congratulate them and add 1 to the total score
            c++;
            System.out.println ("Congrats!! Let's proceed to the next question!");
        }        
        else
        {
            //if not, encourage them to continue
            System.out.println ("Oh no! That's incorrect! That's okay, let's proceed to the next question");
        }

        //tell the user their final score
        System.out.println ("\nYour final score is :" +c );
        if (c>=5)
        {
            //if the user achieves a score above 5, they can proceed to the next level
            System.out.println ("\nGood job! You can proceed to the next level");
            System.out.println ("\nYAY! You did amazing!! However, Moana had a horrible time figuring out how to sail the canoe. A wave flipped her canoe over! ");
            System.out.println ("Then, her foot got trapped within some coral but manages to free herself. She now has a bruised ankle and does not feel ");
            System.out.println ("well about what just happened. Her grandma comes by and notices what had happened, however, she promises to not tell her"); 
            System.out.println ("father. ");
            stage2 ();
        }
        else 
        {
            //if not, they leave
            quit ();
        }
    }

    public void stage2 ()
    {
        //use ascii art to welcome user to stage 2
        System.out.println ("\n ######  ########    ###     ######   ########     ####### "); 
        System.out.println ("##    ##    ##      ## ##   ##    ##  ##          ##     ##"); 
        System.out.println ("##          ##     ##   ##  ##        ##                 ##"); 
        System.out.println (" ######     ##    ##     ## ##   #### ######       ####### "); 
        System.out.println ("      ##    ##    ######### ##    ##  ##          ##       "); 
        System.out.println ("##    ##    ##    ##     ## ##    ##  ##          ##       "); 
        System.out.println (" ######     ##    ##     ##  ######   ########    #########"); 

        //continue the story
        System.out.println ("\nMoana’s grandma introduces the story of the past to Moana and shows her that everyone on the island were once voyagers at sea.");
        System.out.println ("She gives Moana a necklace with the heart inside and tells her to restore the heart. Then, she shows a constellation of Maui’s ");
        System.out.println ("hook. She explains that Maui is beneath it and one day, someone will restore the heart and save the island. Moana is now ");
        System.out.println ("determined to find Maui and ask him to help her restore the heart! Moana realizes that the ocean helps her when she begins to");
        System.out.println ("sail and uses the constellation to help guide her. ");

        System.out.println ("\nYou have to help her find Maui!!");
        System.out.println ("But wait! Here’s a mini game to make this fun! We have found a magic ball to help predict whether or not you will help Moana ");
        System.out.println ("find Maui!");

        char continuemb = IBIO.inputChar ("Do you want to continue and find out what the magic ball says? (y/n): ");
        if (continuemb == 'y')
        {
            magicball ();
        }
        else
        {
            quit();
        }
    }

    public void magicball ()
    {
        System.out.println ("\nWill you be able to help Moana restore the heart?");
        System.out.println ("The magic ball says...");

        //use the magic ball code to use as a mini game
        int num = (int)(Math.random () * 10) + 1;
        //if result is negative, encourage player to continue
        //if result is positive, continue
        if (num==1)
        {
            System.out.println ("doesn't look so good :(  ");
            System.out.println ("it's okay! this magic ball is probably incorrect!");
        }
        else if (num==2)
        {
            System.out.println ("don't count on it :( ");
            System.out.println ("it's okay! this magic ball is probably incorrect!");
        }
        else if (num==3)
        {
            System.out.println ("my sources say no :( ");
            System.out.println ("it's okay! this magic ball is probably incorrect!");
        }
        else if (num==4)
        {
            System.out.println ("of course!! :) ");
            System.out.println ("YAAYYY!! ");
        }
        else if (num==5)

        {
            System.out.println ("it is certain!! :)");
            System.out.println ("YAAYYY!! ");
        }
        else if (num==6)
        {
            System.out.println ("most likely :)");
            System.out.println ("YAAYYY!! ");
        }
        else if (num==7)
        {
            System.out.println ("my reply is no :(");
            System.out.println ("it's okay! this magic ball is probably incorrect!");
        }
        else if (num==8)
        {
            System.out.println ("as I see it yes");
            System.out.println ("YAAYYY!! ");
        }
        else if (num==9)
            System.out.println ("the ball does not know ");
        else if (num==10)
        {
            System.out.println ("yes definitely");
            System.out.println ("YAAYYY!! ");
        }

        //introduce the next part of the game
        System.out.println ("\nOkay, now you have to use your amazing Math Skills and answer the following questions correctly in order to help her find Maui!");

        //use a variable to count points
        int p = 0;
        //use a loop to generate 5 random addition questions
        for (int i = 0 ; i<5 ; i++)
        {
            int add = (int)(Math.random () * 10) + 1;
            int add2 = (int)(Math.random () * 10) + 1;
            int sum = add+add2;
            System.out.println ("\nADD: " + add +  " + " + add2); 
            int addquestion = IBIO.inputInt ("What is the sum of the statement above?: ");
            //if the correct answer matches the user's answer, 1 point is added to the score
            if (sum == addquestion)
            {
                p++;
            }
        }

        //use a variable to count points
        int p2 = 0;
        //use a loop to generate 5 random subtraction questions
        for (int j = 0 ; j<5 ; j++)
        {
            //chooses a random value between 5 and 10 
            int subtract = (int)(5 + Math.random () * 5) + 1;
            //chooses a random value between 1 and 5
            int subtract2 = (int)(Math.random () * 5) + 1;
            //subtracts second value from the first value for correct value, the value should always be positive because the first random value has been 
            //(comment continued from the one above) restricted to 5-10
            int difference = subtract-subtract2;
            //show user the statement they need to solve to proceed
            System.out.println ("\nSUBTRACT: " + subtract +  " - " + subtract2); 
            int subtractquestion = IBIO.inputInt ("What is the difference of the statement above?: ");
            //if the correct answer matches the user's answer, 1 point is added to the score
            if (difference == subtractquestion)
            {
                p2++;
            }
        }

        //use a variable to count points
        int p3 = 0;
        //use a loop to generate 5 random multiplication questions
        for (int k = 0 ; k<5 ; k++)
        {
            int multiply = (int)(Math.random () * 5) + 1;
            int multiply2 = (int)(Math.random () * 5) + 1;
            int product = multiply*multiply2;
            System.out.println ("\nMULTIPLY: "+ multiply + "x" + multiply2);
            int multiplyquestion = IBIO.inputInt ("What is the product of the statement above?: ");
            //if the correct answer matches the user's answer, 1 point is added to the score
            if (product == multiplyquestion)
            {
                p3++;
            }
        }

        //use a variable to keep score
        int p4 = 0;
        //use a loop to generate 5 random division questions
        for (int l = 0 ; l<5 ; l++)
        {
            int divide = (int) (Math.random () * 10) + 1;
            //multiply the first random by 2 so it always even
            int dividefinal = 2*divide;
            //set the second number to 2, so there are no decimal answers
            int divide2 = 2;
            int quotient = dividefinal/divide2;
            System.out.println ("\nDIVIDE: " + dividefinal + "/" + divide2);
            int dividequestion = IBIO.inputInt ("What is the quotient of the statement above?: ");
            //if the correct answer matches the user's answer, 1 point is added to the score
            if (quotient == dividequestion)
            {
                p4++;
            }
        }

        //calculate the totalscore
        int totalscore = p+p2+p3+p4;

        if (totalscore >=15)
        {
            //if the user achieves a total score of above or equal to 15, they can proceed!
            System.out.println ("\nYAY! YOU HAVE HELPED MOANA REACH AN ISLAND! One night, Moana’s canoe reaches an island after a storm hits. ");
            System.out.println ("She is washed up and angry about her situation as she believes that the ocean did not help her. However, she finds ");
            System.out.println ("herself surrounded by rocks with carvings of Maui’s hook. The ocean and your math skills helped Moana deliver her to Maui! ");
            stage3 ();
        }
        else
        {
            //if not, they cannot, and have to leave
            quit ();
        }
    }

    public void stage3 ()
    {
        //use ascii art to introduce user to the new stage
        System.out.println ("\n #####  #######    #     #####  #######     ##### "); 
        System.out.println ("#     #    #      # #   #     # #          #     # ");
        System.out.println ("#          #     #   #  #       #                # ");
        System.out.println (" #####     #    #     # #  #### #####       #####  ");
        System.out.println ("      #    #    ####### #     # #                # ");
        System.out.println ("#     #    #    #     # #     # #          #     # ");
        System.out.println (" #####     #    #     #  #####  #######     #####  ");

        //continue the story
        System.out.println ("\nNow, you have to help Moana convince Maui to help you restore the heart. Wait.. oh no! Maui took Moana’s canoe and trapped");
        System.out.println ("Moana in a cave! You have to use this special magic daisy to predict whether or not Moana will escape!"); 

        //ask the user if they would like to continue
        char continuedaisy = IBIO.inputChar ("Would you like to continue and see what the Magic Daisy's Prediction is? (y/n): ");

        if (continuedaisy == 'y')
        {
            daisy ();
        }
        else
        {
            quit();
        }
    }

    public void daisy ()
    {
        //use daisy ascii to show a visual
        System.out.println ("\nMMMMMMMMMMMMMMMMMMMMMMMMMMMNNMMMMMMMMMMMMMMMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMMMMMMMmddMMh.  `oMMmdmMMMMMMMMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMMMMMN-   .No    .M+   `hMMMMMMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMMMMMd`    :m    oy     oMMMMMMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMh:.-od/    y/   m`   -hh:.-oMMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMN     `+y: :oy++oy/`.ss.     sMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMs-`     ys/------:od.     ./NMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMNyoossoo/s/----------:y/+osssoomMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMM:       .h------------+o       `mMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMo     .-/d------------oy:.`    -NMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMNdhys+-`:s----------/s`-/oyhdmMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMM-      -yoo/----:+oy/      `dMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMN.    :ho`  +h//+h`  :h+`    hMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMNy+omy`    m-   d-    +my+omMMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMMMMMh     oh    /m`    /MMMMMMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMMMMMMs-`.+M+    `Mh-`./mMMMMMMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMMMMMMMMMMMMNo:-/dMMMMMMMMMMMMMMMMMMMMMM");
        System.out.println ("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");

        //code the daisy game for a mini game
        int x = (int) (Math.random () * 10)+ 1;

        for (int a = 0 ; a<=x ; a++)
        {
            if (a%2==0)
            {
                //if number is even, print moana got out
                System.out.println ("Moana got out!");
            }
            else 
            {
                //if number is odd, print moana did not get out
                System.out.println ("Moana did not get out!");
            }
        }
        //use code to make print slower
        try
        {
            Thread.sleep (100);
        }
        catch (InterruptedException m)
        {
            ;
        }

        //if the final prediction is positive, congratulate the player
        if (x%2 == 0)
        {
            System.out.println ("\nYAYY! The daisy predicted right!");
        }
        //if the final prediction is negative, encourage the player and tell them the daisy is incorrect 
        else 
        {
            System.out.println ("\nOH NO! This daisy is probably incorrect!");
        }
        //continue the story
        System.out.println ("\nMoana got out!! And she caught Maui before he escaped as the ocean wouldn’t let him leave! She finally convinces him to help her");
        System.out.println ("restore the heart!! First, they have to find Maui’s hook! They went to Latotai, the realm of monsters!! Moana and Maui know that");
        System.out.println ("Tamatoa, a creature that loves to collect shiny and valuable objects will have the hook. They have to find the hook without"); 
        System.out.println ("being caught!! You have to win this game of Snakes and Ladders in order to retrieve the hook! ");

        //set variables for player of # of square and sum of dice
        int square = 1;
        int dice = 2;

        //greet player and give them instructions
        System.out.println ("\nWelcome to Snakes and Ladders!!");
        System.out.println ("If you roll a sum of dice that is equivalent to 0 or 1, you quit the game!");

        //begin the game
        while (dice >=2 && dice<=12 && square<100 || square==100)
        {
            //ask user to enter sum
            dice = IBIO.inputInt ("\nEnter sum of dice (between 2 and 12): ");

            //after each roll, add sum of dice to get the square # that user is on
            square = dice + square;

            //what happens if you are on a square that is a snake or ladder
            if (square == 54)
            {
                square = 19;
                System.out.println ("OH NO! A SNAKE!");
            }
            else if (square == 90)
            {
                square = 48;
                System.out.println ("OH NO! A SNAKE!");
            }

            else if (square == 99)
            {
                square = 77;
                System.out.println ("OH NO! A SNAKE!");
            }

            else if (square == 9)
            {
                square = 34;
                System.out.println ("YAY! A LADDER!");
            }

            else if (square == 40)
            {
                square = 64;
                System.out.println ("YAY! A LADDER!");
            }

            else if (square == 67)
            {
                square = 86;
                System.out.println ("YAY! A LADDER!");
            }

            //tell the user what square they are on
            System.out.println ("You are now on square: " +square);
        }

        //if user rolls a sum less than or equal to 1, or greater than 12, they quit
        if (dice <=1 || dice>12)
        {
            quit ();
        }
        //if the user lands on 100 or past it, they win
        if (square>=100)
        {
            System.out.println ("\nYOU WON!!");
            RPS ();
        }
    }

    public void RPS ()
    {
        //continue the story
        System.out.println ("\nThey got the hook without getting caught!! But, can Maui still shapeshift? Oh no! He’s having trouble! Moana says that it’s not");
        System.out.println ("the hook that makes him a demigod, it’s him! ");

        System.out.println ("\nWin this game of Rock, Paper, Scissors to help Maui redeem his confidence and ability to shapeshift!!");

        //code game of Rock, Paper, Scissors to help Maui redeem his confidence and ability to shapeshift

        System.out.println ("Welcome! Let's play Rock, Paper, Scissors!");

        //create variables for the number of losses, wins and ties
        int W = 0;
        int T = 0;
        int L = 0;

        //begin the game
        System.out.println ("\nOkay! Let's play!");
        System.out.println ("\nTo play this game, you have three options! Rock (R), Paper (P), and Scissors (S)! Scissors beats Paper, Paper beats Rock, Rock beats Scissors!");

        //play a total of 5 games
        for (int g = 1 ; g<=5 ; g++)
        {
            //ask player to enter choice
            char playerchoice = IBIO.inputChar ("Enter an Uppercase letter to select an object! (R or P or S) ");
            int computerchoice = (int) (Math.random() * 3) + 1;

            if (computerchoice == 1)
            {
                System.out.println ("\nThe computer has selected Rock!");
            }
            if (computerchoice == 2)
            {
                System.out.println ("\nThe computer has selected Paper!");
            }
            if (computerchoice == 3)
            {
                System.out.println ("\nThe computer has selected Scissors!");
            }

            //tell the player if they lost, won or tied
            if ((computerchoice == 1 && playerchoice == 'R') || (computerchoice == 2 && playerchoice == 'P') || (computerchoice == 3 && playerchoice == 'S'))
            {
                System.out.println ("\nIt's a tie!");
                T++;
            }
            if ((computerchoice == 3 && playerchoice == 'R') || (computerchoice == 1 && playerchoice == 'P') || (computerchoice == 2 && playerchoice == 'S'))
            {
                System.out.println ("\nYou win!");
                W++;
            }
            if ((computerchoice == 2 && playerchoice == 'R') || (computerchoice == 3 && playerchoice == 'P') || (computerchoice == 1 && playerchoice == 'S'))
            { 
                System.out.println ("\nYou Lost");
                L++;
            }

            //tell them the total number of wins, ties or losses
            System.out.println ("\nWins: "+W);
            System.out.println ("Ties: "+T); 
            System.out.println ("Losses: "+L);
        }

        //if they won or tied more than three times they can continue
        if (W>=3 || T>=3)
        {
            System.out.println ("\nYAYY! Maui can shapeshift again!! Now, you have to travel to Te Ka and restore the heart!!");
            stage4 ();
        }
        //if not, the player cannot contine
        else 
        {
            quit ();
        } 
    }

    public void stage4 ()
    {
        //use ascii to greet the player to the final stage
        System.out.println ("\n #####  #######    #     #####  #######    #       ");
        System.out.println ("#          #      # #   #     # #          #    #  ");    
        System.out.println ("#          #     #   #  #       #          #    #  ");
        System.out.println (" #####     #    #     # #  #### #####      #    #  ");
        System.out.println ("      #    #    ####### #     # #          ####### ");
        System.out.println ("#     #    #    #     # #     # #               #  ");
        System.out.println (" #####     #    #     #  #####  #######         #  ");

        //continue the story
        System.out.println ("\nYou are now at the final stage! You have to help Moana and Maui restore the heart and help the islands from the destruction! ");
        System.out.println ("Moana gives Maui the heart and wishes him luck! He shifts into a hawk and flies toward the island but Te Ka rises up to confront ");
        System.out.println ("him! Maui is knocked out of the sky once again and returns to the canoe. Moana tries to sail to Te Ka but is reflected backwards ");
        System.out.println ("and Maui’s hook breaks!! Maui gets mad at Moana and leaves. Moana is now very upset and discouraged. However, she realizes that ");
        System.out.println ("she needs to use her water powers to trick Te Ka. Te Ka and Moana are now in a battle and Maui comes back to save her as well!! ");
        System.out.println ("Moana realizes that Te Ka’s chest has the same spiral as the heart! The ocean clears a path for Moana so Moana can confront ");
        System.out.println ("Te Ka. Moana tells Te Ka about the heart and Te Ka’s fire and lava calm down. ");

        System.out.println ("\nIf you want Moana to restore the heart, you have to win this final game to help Moana restore the heart.");

        //tell the player how they have to win
        System.out.println ("\nMaui and Te Ka are in a battle! To win the game and help Maui restore the heart, he has to earn exactly 20 points. Maui will get");
        System.out.println ("5 random tries to generate a total score of 20. If Maui cannot achieve a total score of exactly 20 points, he beats Te ka and "); 
        System.out.println ("restores the heart. If Maui, does not, he loses and does not restore the heart. ");

        //ask the user if they would like to continue
        char continuebjs = IBIO.inputChar ("Would you like to continue and finally beat Te Ka and restore the heart? (y/n): ");
        if (continuebjs == 'y')
        {
            BJS();
        }
        else 
        {
            quit ();
        }
    }

    public void BJS ()
    {
        //use black jack shellack code to code the game

        //use two variables to generate two random numbers
        int pcard = (int)(Math.random () * 10) + 1;
        int pcard2 = (int)(Math.random () * 10) + 1;

        //add the total points for a current score
        int tp = pcard+pcard2;

        //tell the user their total score
        System.out.println ("\nYour total is "+tp);

        //if the player's total score is 20, they win
        if (tp == 20)
        {
            System.out.println ("\nYOU WIN!");
        }

        else if (tp<20)
        {
            //if not, they get 5 more tries to get a total of 20 points
            int c = 1;
            while (c<=5)
            {
                //generate random numbers 5 more times or until player says no and add to final score
                char play = IBIO.inputChar ("Would you like to generate another number to add to your score to get 20 points? (y/n): ");
                if (play == 'y')
                {
                    int card = (int) (Math.random () * 10) + 1; 

                    tp+=card;
                    c++;

                    System.out.println ("Your total is "+ tp);

                }

                //if the user denies to choose another card, let them exit and the loop ends
                if (play == 'n')
                {
                    c=10;
                    quit ();
                }

            }

            if (c==6)
            {
                //if the total score is 20, the user wins!!
                if (tp==20)
                {
                    System.out.println ("\nCongratulations!! You helped Moana restore the heart!! When the heart is restored, the lava volcano fades away revealing ");
                    System.out.println ("Te Fiti, a beautiful, green island. You helped Moana save all islands from destruction! Be like Moana and continue to ");
                    System.out.println ("help your community and environment as well! ");

                    //ask the user if they want to play again
                    char playagain = IBIO.inputChar ("Would you like to play again? y/n");
                    //if yes, call first method to restart
                    if (playagain == 'y')
                    {
                        password1 ();
                    }        
                    //else, call last method to exit out of the game
                    else 
                    {
                        bye ();
                    }  
                }

                //if the final score is above or below 20, the user has to exit
                else if (tp<20 || tp>20)
                {
                    quit ();
                } 
            }
        }
    }

    public void quit ()
    {
        //tell the user they weren't able to help Moana
        System.out.println ("\nOh no! You lost! You couldn’t help Moana restore the heart! But you can always play again!");
        //ask the user if they want to play
        char playagain2 = IBIO.inputChar ("\nWould you like to play again? y/n");
        //if yes, call first method to restart the game
        if (playagain2 == 'y')
        {
            password1 ();
        }
        //if no, call final method to exit
        else
        {
            bye ();
        }
    }

    public void bye ()
    {
        System.out.println ("\nBYEE!!");
    }

}


